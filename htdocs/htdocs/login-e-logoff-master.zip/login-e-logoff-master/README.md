# login-e-logoff
Sistema de Login e Logoff - PHP PDO

As senhas dos usuários são criptografadas - Teste o usuário: admin e senha: 123456

----------------------------------------------------------------

Caso queira criptografar a senha de um novo usuário cadastrado você pode acessar esse post: https://www.mundodaprogramacao.com.br/blog/back-end/inserindo-dados-no-banco-de-dados
E aí depois é só usar a comparação feita no login: 
  Verifica primeiro se existe um login cadastrado na base de dados, caso exista você verifica se a senha bate com esse login.
